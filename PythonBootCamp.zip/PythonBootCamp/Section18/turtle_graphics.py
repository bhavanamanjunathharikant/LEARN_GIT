import random
from turtle import *
tom=Turtle()
screen=Screen()
tom.shape("turtle")
# tom.color("green")


#TODO : Draw a square

''' 
for i in range(4):
    tom.right(90)
    tom.forward(100)
'''

#TODO : Draw dash line

'''
for _ in range(10):
    tom.forward(10)
    tom.penup()
    tom.forward(10)
    tom.pendown()

'''

#TODO : Draw a triangle
'''
for _ in range(3):
    tom.forward(150)
    tom.left(120)
'''

#TODO : Draw pentagon
'''
for _ in range(5):
    tom.forward(100)
    tom.left(73)
'''

#TODO : Draw hexagon
'''
for _ in range(6):
    tom.forward(100)
    tom.left(60)
'''

#TODO : Draw heptagon
'''
for _ in range(7):
    tom.forward(100)
    tom.left(51)
'''

#TODO : Draw octagon
'''
for _ in range(8):
    tom.forward(100)
    tom.left(45)
'''

#TODO : Draw nonagon
'''
for _ in range(9):
    tom.forward(100)
    tom.left(40)
'''

#TODO : Draw decagon
'''
for _ in range(10):
    tom.forward(100)
    tom.left(36)
'''
colors=["Emerald","Azure","Saffron","Indigo","Coral","Olive","Turquoise" ,"Amethyst","Cocoa" ,"Pearl" ,"Charcoal" ]
def draw_shape(n_side):
    for _ in range(n_side):
        angle=360/n_side
        tom.forward(100)
        tom.right(angle)

for num_side in range(3,12):
    # tom.color(random.choice(colors))
    draw_shape(num_side)


screen.exitonclick()