import turtle as t
import random

tom=t.Turtle()
t.colormode(255)

def random_color():
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    random_col=(r,g,b)
    return random_col

tom.speed("fastest")
def draw_spirograph(size_of_gap):
    for _ in range(360//size_of_gap):
        tom.color(random_color())
        tom.circle(100)
        current_heading=tom.heading()
        tom.setheading(current_heading+size_of_gap)
        # tom.circle(100)

draw_spirograph(10)
screen=t.Screen()
screen.exitonclick()