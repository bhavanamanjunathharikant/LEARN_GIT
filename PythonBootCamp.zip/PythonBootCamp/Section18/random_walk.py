# import turtle as t
# import random
#
# tom=t.Turtle()
# screen=t.Screen()
#
#
# colors=["Emerald","Azure","Saffron","Indigo","Coral","Olive","Turquoise" ,"Amethyst","Cocoa" ,"Pearl" ,"Charcoal" ]
#
# directions=[0,90,180,270]
#
# for _ in range(200):
#     tom.color(random.choice(colors))
#     tom.forward(30)
#     tom.setheading(random.choice(directions))
#
# screen.exitonclick()

import turtle as t
import random

tom = t.Turtle()
screen = t.Screen()

tom.shape("arrow")  # Makes direction visible
tom.speed(3)        # Slows down for visibility

colors = ["red", "blue", "green", "yellow", "purple", "orange", "cyan", "magenta", "brown", "gray", "pink"]
directions = [0, 90, 180, 270]
tom.pensize(15)
tom.speed("fastest")
for _ in range(200):
    tom.color(random.choice(colors))
    tom.forward(30)
    tom.setheading(random.choice(directions))

screen.exitonclick()
