import colorgram
'''
# Load the image and extract colors
colors = colorgram.extract('image.jpg', 1000)  # Extract up to 1000 colors

# Display all extracted colors
for i, color in enumerate(colors):
    rgb = color.rgb  # NamedTuple of RGB
    print(f"Color {i+1}: RGB = ({rgb.r}, {rgb.g}, {rgb.b})")
'''
colors = colorgram.extract('image.jpg', 30)
print(colors)
rgb_colors=[]
# for color in colors:
#     rgb_colors.append(color.rgb)

for color in colors:
    r=color.rgb.r
    g=color.rgb.g
    b=color.rgb.b
    new_color=(r,g,b)
    rgb_colors.append(new_color)

print(rgb_colors)
'''
[(182, 148, 99), (149, 99, 47), (80, 30, 23), (174, 148, 29), (9, 53, 70), (33, 99, 118), (101, 40, 46), (61, 131, 113), (21, 61, 40), (107, 39, 29), (88, 18, 21), (39, 80, 9), (94, 64, 69), (195, 92, 67), (116, 165, 78), (135, 174, 120), (142, 166, 174), (213, 201, 149), (173, 150, 153), (24, 79, 93), (221, 178, 167), (175, 206, 186), (60, 78, 13), (105, 139, 144), (205, 184, 188), (176, 199, 202)]

'''