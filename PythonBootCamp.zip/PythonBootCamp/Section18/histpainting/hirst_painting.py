import turtle as t
import random

t.colormode(255)
colors=[(182, 148, 99), (149, 99, 47), (80, 30, 23), (174, 148, 29), (9, 53, 70), (33, 99, 118), (101, 40, 46), (61, 131, 113), (21, 61, 40), (107, 39, 29), (88, 18, 21), (39, 80, 9), (94, 64, 69), (195, 92, 67), (116, 165, 78), (135, 174, 120), (142, 166, 174), (213, 201, 149), (173, 150, 153), (24, 79, 93), (221, 178, 167), (175, 206, 186), (60, 78, 13), (105, 139, 144), (205, 184, 188), (176, 199, 202)]

tom=t.Turtle()
tom.penup()
tom.hideturtle()
tom.speed("fastest")
tom.setheading(225)
tom.forward(300)
tom.setheading(0)
number_of_dots=100

for dot_count in range(1,number_of_dots+1):
    tom.dot(20,random.choice(colors))
    tom.forward(50)

    if dot_count %10==0:
        tom.setheading(90)
        tom.forward(50)
        tom.setheading(180)
        tom.forward(500)
        tom.setheading(0)

