import turtle as t

tom=t.Turtle()
screen=t.Screen()

# tom.setheading(225)
# tom.forward(300)
# tom.setheading(0)

tom.right(150)
tom.forward(300)
tom.right(270)
tom.forward(300)
screen.exitonclick()

