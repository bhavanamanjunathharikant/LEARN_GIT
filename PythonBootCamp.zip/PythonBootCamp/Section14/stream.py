import streamlit as st
import random
from game_data import data
from art import hl, vs

# Helper functions
def format_data(account):
    name = account["name"]
    descr = account["description"]
    country = account["country"]
    return f"{name}, a {descr}, from {country}"

def check_answer(user_guess, a_followers, b_followers):
    return (a_followers > b_followers and user_guess == "A") or \
           (b_followers > a_followers and user_guess == "B")

# Initialize session state
if "score" not in st.session_state:
    st.session_state.score = 0
if "account_A" not in st.session_state:
    st.session_state.account_A = random.choice(data)
if "account_B" not in st.session_state:
    st.session_state.account_B = random.choice(data)
    while st.session_state.account_B == st.session_state.account_A:
        st.session_state.account_B = random.choice(data)
if "game_over" not in st.session_state:
    st.session_state.game_over = False

# Display header
st.title("Higher or Lower Game")
st.markdown(f"### {hl}")

# Show accounts
st.subheader("Compare A:")
st.write(format_data(st.session_state.account_A))
st.markdown(vs)
st.subheader("Compare B:")
st.write(format_data(st.session_state.account_B))

# User input
col1, col2 = st.columns(2)
with col1:
    if st.button("Choose A"):
        guess = "A"
    else:
        guess = None
with col2:
    if st.button("Choose B"):
        guess = "B"

# Game logic
if guess and not st.session_state.game_over:
    a_followers = st.session_state.account_A["follower_count"]
    b_followers = st.session_state.account_B["follower_count"]
    is_correct = check_answer(guess, a_followers, b_followers)

    if is_correct:
        st.session_state.score += 1
        st.success(f"You're right! Current score: {st.session_state.score}")
        st.session_state.account_A = st.session_state.account_B
        st.session_state.account_B = random.choice(data)
        while st.session_state.account_B == st.session_state.account_A:
            st.session_state.account_B = random.choice(data)
    else:
        st.error(f"Wrong! Final score: {st.session_state.score}")
        st.session_state.game_over = True

# Restart button
if st.session_state.game_over:
    if st.button("Play Again"):
        st.session_state.score = 0
        st.session_state.account_A = random.choice(data)
        st.session_state.account_B = random.choice(data)
        while st.session_state.account_B == st.session_state.account_A:
            st.session_state.account_B = random.choice(data)
        st.session_state.game_over = False
