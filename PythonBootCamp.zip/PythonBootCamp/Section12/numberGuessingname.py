import random
symbol="""
 ________                               _______               ___.                 
 /  _____/ __ __   ____   ______ ______  \      \  __ __  _____\_ |__   ___________ 
/   \  ___|  |  \_/ __ \ /  ___//  ___/  /   |   \|  |  \/     \| __ \_/ __ \_  __ \
\    \_\  \  |  /\  ___/ \___ \ \___ \  /    |    \  |  /  Y Y  \ \_\ \  ___/|  | \/
 \______  /____/  \___  >____  >____  > \____|__  /____/|__|_|  /___  /\___  >__|   
        \/            \/     \/     \/          \/            \/    \/     \/       
"""

def guess_number(num,ll):
    print("You have 10 attempts remaining to guess the number.")
    n=ll
    while n>0:
        g=int(input("Make a guess:"))
        if g>num:
            print("Too high")
        elif g<num:
            print("Too low")
        else:
            return True
        n-=1
        if n>0:
            print("Guess again")
            print(f"You have {n} attempts remaining to guess the number.")
    return False

if __name__=='__main__':
    print(symbol)
    print('Welcome to the Number Guessing Game!')
    print("I'm thinking of a number between 1 and 100.")
    number=random.randint(1,100)
    level=input("Choose a difficulty. Type 'easy' or 'hard':")
    l=0
    if level=='easy':
        l=10
    elif level=='hard':
        l=5
    else:
        print("Your selection is wrong try again!")

    result=guess_number(number,l)
    if result:
        print(f"You got it! The answer was {number}")
    else:
        print("You've run out of guesses. Refresh the page to run again.")